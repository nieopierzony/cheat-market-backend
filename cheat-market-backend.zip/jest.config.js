module.exports = {
  setupFilesAfterEnv: ['./test/mocks/redis-mock.js'],
};
